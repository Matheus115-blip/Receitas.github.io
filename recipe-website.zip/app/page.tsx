import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, Users, Star, ChefHat, Heart, Search } from "lucide-react"

export default function RecipePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <ChefHat className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold text-primary">Sabores & Receitas</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="text-foreground hover:text-primary transition-colors">
              Receitas
            </a>
            <a href="#" className="text-foreground hover:text-primary transition-colors">
              Categorias
            </a>
            <a href="#" className="text-foreground hover:text-primary transition-colors">
              Destaques
            </a>
            <a href="#" className="text-foreground hover:text-primary transition-colors">
              Sobre
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Search className="h-4 w-4" />
            </Button>
            <Button size="sm">Entrar</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('/delicious-colorful-pasta-dish-with-fresh-herbs-and.jpg')`,
          }}
        >
          <div className="absolute inset-0 bg-black/40" />
        </div>
        <div className="relative z-10 text-center text-white px-4 max-w-4xl">
          <h2 className="text-5xl md:text-7xl font-bold mb-6 text-balance drop-shadow-lg">Desperte Seus Sentidos</h2>
          <p className="text-xl md:text-2xl mb-8 text-balance drop-shadow-md">
            Descubra receitas incríveis que vão transformar sua cozinha em um paraíso gastronômico
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6 shadow-lg">
              Explorar Receitas
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 bg-white/10 backdrop-blur border-white/30 text-white hover:bg-white/20"
            >
              Ver Destaques
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4">
        <div className="container max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-4xl font-bold mb-4 text-balance">Explore por Categoria</h3>
            <p className="text-xl text-muted-foreground text-balance">Encontre a receita perfeita para cada ocasião</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                name: "Pratos Principais",
                image: "grilled salmon with roasted vegetables and herbs",
                count: "120+ receitas",
              },
              {
                name: "Sobremesas",
                image: "chocolate lava cake with vanilla ice cream and berries",
                count: "85+ receitas",
              },
              { name: "Aperitivos", image: "colorful bruschetta with tomatoes and basil", count: "60+ receitas" },
              { name: "Bebidas", image: "tropical fruit smoothie with mint garnish", count: "40+ receitas" },
            ].map((category, index) => (
              <Card
                key={index}
                className="group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative h-48 overflow-hidden">
                  <div
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-300 group-hover:scale-110"
                    style={{
                      backgroundImage: `url('/--category-image-.jpg')`,
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 text-white">
                    <h4 className="text-xl font-bold mb-1">{category.name}</h4>
                    <p className="text-sm opacity-90">{category.count}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Recipes */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-4xl font-bold mb-4 text-balance">Destaques do Dia</h3>
            <p className="text-xl text-muted-foreground text-balance">
              As receitas mais populares escolhidas especialmente para você
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Risotto de Camarão com Açafrão",
                description:
                  "Um prato cremoso e aromático que combina perfeitamente camarões frescos com o sabor único do açafrão",
                time: "35 min",
                servings: "4 pessoas",
                rating: 4.8,
                image: "creamy saffron shrimp risotto with fresh herbs in elegant bowl",
              },
              {
                title: "Bolo de Chocolate Belga",
                description: "Sobremesa irresistível com chocolate belga derretido e cobertura de ganache sedosa",
                time: "1h 20min",
                servings: "8 pessoas",
                rating: 4.9,
                image: "rich belgian chocolate cake with glossy ganache and berries",
              },
              {
                title: "Salada Mediterrânea Fresca",
                description: "Combinação vibrante de ingredientes frescos com azeite extra virgem e ervas aromáticas",
                time: "15 min",
                servings: "2 pessoas",
                rating: 4.7,
                image: "colorful mediterranean salad with olives tomatoes and feta cheese",
              },
            ].map((recipe, index) => (
              <Card
                key={index}
                className="group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div className="relative h-64 overflow-hidden">
                  <div
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-300 group-hover:scale-105"
                    style={{
                      backgroundImage: `url('/--recipe-image-.jpg')`,
                    }}
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-xl group-hover:text-primary transition-colors">{recipe.title}</CardTitle>
                    <div className="flex items-center gap-1 text-sm">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{recipe.rating}</span>
                    </div>
                  </div>
                  <CardDescription className="text-base leading-relaxed">{recipe.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{recipe.time}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{recipe.servings}</span>
                    </div>
                  </div>
                  <Button className="w-full mt-4 bg-transparent" variant="outline">
                    Ver Receita Completa
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 px-4 bg-primary text-primary-foreground">
        <div className="container max-w-4xl mx-auto text-center">
          <h3 className="text-4xl font-bold mb-4 text-balance">Receba Receitas Exclusivas</h3>
          <p className="text-xl mb-8 opacity-90 text-balance">
            Cadastre-se e receba semanalmente nossas melhores receitas direto no seu email
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Seu melhor email"
              className="flex-1 px-4 py-3 rounded-lg text-foreground bg-white border-0 focus:ring-2 focus:ring-white/50"
            />
            <Button size="lg" variant="secondary" className="px-8">
              Cadastrar
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-muted/50">
        <div className="container max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <ChefHat className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">Sabores & Receitas</span>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Transformando sua cozinha em um espaço de criatividade e sabor.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Receitas</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Pratos Principais
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Sobremesas
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Aperitivos
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Bebidas
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Comunidade</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Dicas de Cozinha
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Eventos
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Newsletter
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Contato
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Política de Privacidade
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    Termos de Uso
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 Sabores & Receitas. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
